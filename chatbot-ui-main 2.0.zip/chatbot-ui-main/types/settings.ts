export interface Settings {
  theme: 'light' | 'dark';
}
